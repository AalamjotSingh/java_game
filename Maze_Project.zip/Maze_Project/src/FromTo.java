public class FromTo {
   public int from_row;
   public int from_col;
   public int to_row;
   public int to_col;
   
   
   public FromTo( int from_row, int from_col, int to_row, int to_col)
   {
       this.from_row = from_row;
       this.from_col = from_col;
       this.to_row = to_row;
       this.to_col = to_col;
       
   }
}
